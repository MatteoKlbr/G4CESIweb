<footer>
    <p style="text-align:center;">&copy;2025 - Tous droits réservés - StageElevate</p>
</footer>
</body>
</html>
