<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>

<header></header>  
<main>

<?php
Question1-1
const SITE_NAME = "MonSiteWeb";
Question1-2

$greeting = "Bienvenue sur";
Question1-3

echo($greeting . " " . SITE_NAME);
Question1-4

$array = [$alice = 15, $bob = 12, $charlie = 18];
Question1-5
for($i = 0; $i < 3, $i++){
Question2-1

    echo($array[i]);
    if($array[i] >= 15){
        echo "Excellent";
    }
Question2-2

    elseif($array[i] < 10){
        this->$array[i]++;
    }
}
Question3-1

function formaText($text){
    return stroupper($text);
}
Question3-1

include "footer.html"
?>


<main>

</body>
</html>
