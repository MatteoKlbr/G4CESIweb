</main>
<link rel="stylesheet" href="footer.css">
<footer>
    <em>&copy;2025 - Tous droits réservés - StageElevate</em> |
    <a href="cookies.html">Politique des cookies</a> |
    <a href="mentions-legales.html">Mentions légales</a>
</footer>

<!-- Inclure la modale du profil -->
<?php include 'profile.php'; ?>

<!-- Bootstrap JS CDN -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
