<?php 
$pageTitle = "Accueil - LeBonPlan";
$pageDescription = "Trouvez votre stage ou alternance sur LeBonPlan.";
include 'header.php';
?>
<link rel="stylesheet" href="Accueil.css">


<section class="home-section">
  <h1>Trouvez votre stage ou alternance</h1>
  <a href="Offres.php" class="btn-offres">Voir les offres</a>
</section>

<?php include 'footer.php'; ?>
