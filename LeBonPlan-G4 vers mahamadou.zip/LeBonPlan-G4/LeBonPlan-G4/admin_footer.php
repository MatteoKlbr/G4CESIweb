<footer>
    <p style="text-align:center;">&copy;2025 - Tous droits réservés - Web4All</p>
</footer>
</body>
</html>
